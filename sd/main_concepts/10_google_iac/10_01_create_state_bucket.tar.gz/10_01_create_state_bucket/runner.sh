filepath=$(dirname $(pwd))/10_00_credentials/terraform.json
bucket_name="unlu-tf-state"
prefix="terraform/state"

terraform init --var credentials_file_path=$filepath \
    --backend-config bucket=$bucket_name \
    --backend-config prefix=$prefix \
    --backend-config credentials=$filepath

terraform plan --var credentials_file_path=$filepath